﻿using SSoS_HS;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace myLibrary
{
    class Program
    {
        static void Main()
        {
            //Console.WriteLine(decimal.MaxValue);
            //Console.WriteLine(ulong.MaxValue);
            Console.WriteLine("Enter Two Prime Numbers...");
            Console.WriteLine("For Example: 173, 191, 193, 1399, 1409, 1427, 11689, 11699, 11701");
            ulong PrimeNumber1 = Convert.ToUInt64(Console.ReadLine());
            ulong PrimeNumber2 = Convert.ToUInt64(Console.ReadLine()); //product of p&q should be greater than 95 and q!= q;

            ulong EncryptionKey = 0, DecryptionKey = 0, Mod_n = 0;
            Encryptor E = new Encryptor();            
            string Error = E.KeyGenerator(PrimeNumber1, PrimeNumber2, ref Mod_n, ref  EncryptionKey, ref  DecryptionKey);
            Console.WriteLine(Error);
            if (Error != "successful") { Main(); }
            Console.WriteLine("Encryption Key is " + EncryptionKey);
            Console.WriteLine("Decryption Key is " + DecryptionKey);
            Console.WriteLine("Mod 'n' is " + Mod_n);
            
            dataEncrypt obj = new dataEncrypt();
            Console.Write("Enter The Data: ");
            string data = Console.ReadLine(); //Reading("C:/Users/hashi/Desktop/hey.txt");
            string encryptedText = obj.Encrypt(EncryptionKey, Mod_n, data, 1);              // 1 for encryption.
            Console.WriteLine("Encrypted Text is: " + encryptedText);
            //Writing(encryptedText, "C:/Users/hashi/Desktop/hey.txt");
            string decryptedText = obj.Encrypt(DecryptionKey, Mod_n, encryptedText, 2);     // 2 for decryption
            Console.WriteLine("Decrypted Text is: "+ decryptedText);

        }
        static string Reading(string Path)
        {
            string Data = null;
            try
            {
                using (StreamReader sr = new StreamReader(Path))
                {
                    string line;
                    for (int i = 0; (line = sr.ReadLine()) != null; i++)
                    {
                        //Console.WriteLine(line);
                        //line = line + "  "/*n\*/;
                        Data = Data + line;
                        //Console.WriteLine(line.Count());
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
            }
            Console.WriteLine(Data);
            return (Data);
        }
        static string Writing(string Data, string Path)
        {
            try
            {
                using (StreamWriter fw = new StreamWriter /*File.AppendText*/(Path))
                {
                    fw.WriteLine(Data);
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("The file could not be write:");
                Console.WriteLine(e.Message);
            }
            return ("File has been Written");
        }
    }
}